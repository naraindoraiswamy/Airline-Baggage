package com.ge.predix.airline.postgresql;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ge.predix.airline.postgresql.entity.BaggageInfoEntity;
import com.ge.predix.airline.postgresql.model.BaggageModel;
import com.ge.predix.airline.postgresql.repository.IBaggageInfoEntityRepository;
import com.ge.predix.airline.postgresql.util.ConvertEntityToModel;
import com.ge.predix.airline.postgresql.util.ConvertModelToEntity;

@RestController
public class BaggageService {
	
	@Autowired
	private IBaggageInfoEntityRepository baggageService;
	
	@Autowired
	private ConvertEntityToModel convertEntityToModel;
	
	@Autowired
	private ConvertModelToEntity convertModelToEntity;

	
        @RequestMapping(value = "/getBaggageInfo",method = RequestMethod.GET )
    	public @ResponseBody List<BaggageModel> getBaggageInfo() {
    		List<BaggageModel> baggageModelList = new ArrayList<BaggageModel>();
    		Iterable<BaggageInfoEntity> baggageInfoEntities = this.baggageService.findAll();
    		for (BaggageInfoEntity baggageInfoEntity : baggageInfoEntities) {
    			baggageModelList.add(convertEntityToModel.getBaggageModel(baggageInfoEntity));
    		}
    		System.out.println("Number of BaggageList Size :  "+ baggageModelList.size());
    		return baggageModelList;
    	}
        
        
        @RequestMapping(value = "/saveBaggageInfo", method = RequestMethod.POST)       
    	public @ResponseBody ResponseEntity<String> saveBaggageInfo(HttpServletRequest request) {
        	String response = "";
        	System.out.println("Inside saveBaggageInfo");
        	ObjectMapper mapper = new ObjectMapper();
        	try {
        		BaggageModel baggageModel = mapper.readValue( request.getInputStream(), BaggageModel.class);
        		BaggageInfoEntity baggageInfoEntity = convertModelToEntity.setBaggageInfoEntity(baggageModel);
        		List<BaggageInfoEntity> baggageInfoEntityList = this.baggageService.getBaggageId(baggageInfoEntity.getUniqueBagId());
        		if(baggageInfoEntityList != null && !baggageInfoEntityList.isEmpty()){
        			BaggageInfoEntity existedBaggageInfoEntity = baggageInfoEntityList.get(0);
        			baggageService.delete(existedBaggageInfoEntity);
        		} 
        			baggageService.save(baggageInfoEntity);
        		System.out.println("Baggage information updated successfully.");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				 return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Unable to persist baggage information.");
				
			}
    		return ResponseEntity.status(HttpStatus.OK).body("Baggage information updated successfully.");
    	}
        
        
     
}
