package com.ge.predix.airline.postgresql;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ge.predix.airline.postgresql.entity.ItineraryEntity;
import com.ge.predix.airline.postgresql.entity.MappingBagEntity;
import com.ge.predix.airline.postgresql.model.ItineraryModel;
import com.ge.predix.airline.postgresql.model.MappingItineraryAndBagModel;
import com.ge.predix.airline.postgresql.model.MappingItineraryModel;
import com.ge.predix.airline.postgresql.repository.IBaggageInfoEntityRepository;
import com.ge.predix.airline.postgresql.repository.IItineraryEntityRepository;
import com.ge.predix.airline.postgresql.repository.IMappingBagEntityRepository;
import com.ge.predix.airline.postgresql.util.ConvertEntityToModel;
import com.ge.predix.airline.postgresql.util.ConvertModelToEntity;

@RestController
public class ItineraryService {

	@Autowired
	private IItineraryEntityRepository itineraryService;

	@Autowired
	private IMappingBagEntityRepository mappingBagAndItineraryService;
	
	@Autowired
	private IBaggageInfoEntityRepository baggageService;
	

	@Autowired
	private ConvertEntityToModel convertEntityToModel;

	@Autowired
	private ConvertModelToEntity convertModelToEntity;

	@RequestMapping(value = "/getItineraryInfo/{itineraryId}", method = RequestMethod.GET)
	public @ResponseBody MappingItineraryModel getBaggageInfo(
			@PathVariable String itineraryId) {
		MappingItineraryModel mappingItineraryModel = new MappingItineraryModel();
		LinkedList<ItineraryModel> itineraryModelList = new LinkedList<ItineraryModel>();
		
		//Get Itinerary List for selected ID
		LinkedList<ItineraryEntity> itineraryEntityList = this.itineraryService
				.getItineraryListById(itineraryId);		
		List<String> selectedBaggageIdList = this.mappingBagAndItineraryService.getMappingBaggageListByItineraryId(itineraryId);
		List<String> baggageIdList = this.baggageService.getBaggageList();
		if(itineraryEntityList != null && !itineraryEntityList.isEmpty()){
			for (ItineraryEntity itineraryEntity : itineraryEntityList) {
				itineraryModelList.add(convertEntityToModel
						.getItineraryModel(itineraryEntity));
			}
		}
		
		if(selectedBaggageIdList != null && !selectedBaggageIdList.isEmpty()){
			for (String selectedBaggageId : selectedBaggageIdList) {
				if(baggageIdList.contains(selectedBaggageId)){
					baggageIdList.remove(selectedBaggageId);
				} 
				
			}
		}
		
		mappingItineraryModel.setItineraryModelList(itineraryModelList);
		mappingItineraryModel.setSelectedBaggageIdList(selectedBaggageIdList);
		mappingItineraryModel.setNonSelectedBaggageIdList(baggageIdList);
		System.out.println("Number of BaggageList Size :  "
				+ itineraryModelList.size());
		System.out.println("Number of Selected BaggageList Size :  "
				+ selectedBaggageIdList.size());
		System.out.println("Number of Non- Selected BaggageList Size :  "
				+ baggageIdList.size());
		return mappingItineraryModel;
	}

	@RequestMapping(value = "/getItineraryInfo", method = RequestMethod.GET)
	public @ResponseBody LinkedList<String> getBaggageInfo() {

		LinkedList<String> itineraryEntityIdList = this.itineraryService
				.getItineraryList();

		System.out.println("Number of BaggageList Size :  "
				+ itineraryEntityIdList.size());
		return itineraryEntityIdList;
	}

	@RequestMapping(value = "/mapItineraryAndBag", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity<String> mapItineraryAndBag(
			HttpServletRequest request) {
		System.out.println("Inside saveBaggageInfo");
		ObjectMapper mapper = new ObjectMapper();
		List<MappingBagEntity> mappingBagEntityList = new ArrayList<MappingBagEntity>();
		try {
			MappingItineraryAndBagModel mappingItineraryAndBagModel = mapper
					.readValue(request.getInputStream(),
							MappingItineraryAndBagModel.class);
			String itineraryId = mappingItineraryAndBagModel.getItineraryId();
			List<String> baggageList = mappingItineraryAndBagModel
					.getUniqueBagId();
			List<MappingBagEntity> mappingObjList = this.mappingBagAndItineraryService.getMappingObjByItineraryId(itineraryId);
			if(mappingObjList != null && !mappingObjList.isEmpty()){
				for (MappingBagEntity mappingBagEntity : mappingObjList) {
					this.mappingBagAndItineraryService.delete(mappingBagEntity);
				}
			}
			for (String baggageId : baggageList) {
				mappingBagEntityList.add(new MappingBagEntity(baggageId,itineraryId));
			}
			
			this.mappingBagAndItineraryService.save(mappingBagEntityList);
			System.out.println("Check-in details updated successfully.");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(
					"Unable to persist baggage information.");

		}
		return ResponseEntity.status(HttpStatus.OK).body(
				"Check-in details updated successfully.");
	}

}
