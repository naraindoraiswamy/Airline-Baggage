package com.ge.predix.airline.postgresql;
/*package com.ge.predix.solsvc.training.alarmservice.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ge.predix.solsvc.training.alarmservice.model.MappingItineraryAndBagModel;


@Service
public class MappingBagAndItineraryService {
	
	public boolean mappingItineraryAndBag(MappingItineraryAndBagModel mappingItineraryAndBagModel)
    {
		boolean status = false;
		String itineraryId = mappingItineraryAndBagModel.getItineraryId();
		List<String> baggageList = mappingItineraryAndBagModel.getUniqueBagId();
		for (String baggageId : baggageList) {
			
		}
	
    return status;
    }

}
*/