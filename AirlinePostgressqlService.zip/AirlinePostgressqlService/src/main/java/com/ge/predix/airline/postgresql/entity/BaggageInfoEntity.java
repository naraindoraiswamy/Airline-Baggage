package com.ge.predix.airline.postgresql.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the baggageinfo database table.
 * 
 */
@Entity
@Table(name = "baggageinfo")
@NamedQuery(name = "BaggageInfoEntity.findAll", query = "SELECT b FROM BaggageInfoEntity b")
public class BaggageInfoEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idbaggage;

	private String description;

	private String imei;

	private String uniqueBagId;

	private int dimensions;

	private int weight;

	private String status;

	public BaggageInfoEntity() {
	}

	public BaggageInfoEntity(String description, String imei,
			String uniqueBagId, int dimensions, int weight, String status) {
		super();
		this.description = description;
		this.imei = imei;
		this.uniqueBagId = uniqueBagId;
		this.dimensions = dimensions;
		this.weight = weight;
		this.status = status;

	}

	public int getIdbaggage() {
		return this.idbaggage;
	}

	public void setIdbaggage(int idbaggage) {
		this.idbaggage = idbaggage;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getImei() {
		return this.imei;
	}

	public void setImei(String imei) {
		this.imei = imei;
	}

	public String getUniqueBagId() {
		return this.uniqueBagId;
	}

	public void setUniqueBagId(String uniqueBagId) {
		this.uniqueBagId = uniqueBagId;
	}

	public int getDimensions() {
		return dimensions;
	}

	public void setDimensions(int dimensions) {
		this.dimensions = dimensions;
	}

	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}