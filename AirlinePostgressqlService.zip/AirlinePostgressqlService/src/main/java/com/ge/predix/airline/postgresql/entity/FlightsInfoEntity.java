package com.ge.predix.airline.postgresql.entity;
/*package com.ge.predix.solsvc.training.alarmservice.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

*//**
 * The persistent class for the flightsinfo database table.
 * 
 *//*
@Entity
@Table(name = "flightsinfo")
@NamedQuery(name = "FlightsInfoEntity.findAll", query = "SELECT f FROM FlightsInfoEntity f")
public class FlightsInfoEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idflight;

	private String flightDestination;

	private String flightName;

	private String flightSource;

	private int hops;

	private String operatedBy;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date departure;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date arrival;
	
	

	// bi-directional many-to-one association to Flightitinerary
	@ManyToOne
	@JoinColumn(name = "idItinerary")
	private ItineraryEntity flightitinerary;

	public FlightsInfoEntity() {
	}

	public FlightsInfoEntity(String flightName, String flightSource,
			String flightDestination,Date departure, Date arrival, int hops, String operatedBy) {
		super();

		this.flightDestination = flightDestination;
		this.flightName = flightName;
		this.flightSource = flightSource;
		this.departure = departure;
		this.arrival = arrival;
		this.hops = hops;
		this.operatedBy = operatedBy;

	}

	public int getIdflight() {
		return this.idflight;
	}

	public void setIdflight(int idflight) {
		this.idflight = idflight;
	}

	public String getFlightDestination() {
		return this.flightDestination;
	}

	public void setFlightDestination(String flightDestination) {
		this.flightDestination = flightDestination;
	}

	public String getFlightName() {
		return this.flightName;
	}

	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}

	public String getFlightSource() {
		return this.flightSource;
	}

	public void setFlightSource(String flightSource) {
		this.flightSource = flightSource;
	}

	public int getHops() {
		return this.hops;
	}

	public void setHops(int hops) {
		this.hops = hops;
	}

	public String getOperatedBy() {
		return this.operatedBy;
	}

	public void setOperatedBy(String operatedBy) {
		this.operatedBy = operatedBy;
	}

	public ItineraryEntity getFlightitinerary() {
		return this.flightitinerary;
	}

	public void setFlightitinerary(ItineraryEntity flightitinerary) {
		this.flightitinerary = flightitinerary;
	}

	public Date getDeparture() {
		return departure;
	}

	public void setDeparture(Date departure) {
		this.departure = departure;
	}

	public Date getArrival() {
		return arrival;
	}

	public void setArrival(Date arrival) {
		this.arrival = arrival;
	}
	
	
}*/