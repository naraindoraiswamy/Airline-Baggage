package com.ge.predix.airline.postgresql.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the flightitinerary database table.
 * 
 */
@Entity
@Table(name = "itinerary")
@NamedQuery(name = "ItineraryEntity.findAll", query = "SELECT f FROM ItineraryEntity f")
public class ItineraryEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idFlightItinerary;

	@Column(name = "class")
	private String class_;

	private String destination;

	@Temporal(TemporalType.TIMESTAMP)
	private Date travelEndDate;

	private String itineraryId;

	private String source;

	@Temporal(TemporalType.TIMESTAMP)
	private Date travelStartDate;

	// Flight Details

	private String flightDestination;

	private String flightName;

	private String flightSource;

	private int hops;

	private String operatedBy;

	@Temporal(TemporalType.TIMESTAMP)
	private Date flightDeparture;

	@Temporal(TemporalType.TIMESTAMP)
	private Date flightArrival;
	
	private Double flightSourceLatitude;
	
	private Double flightSourceLongitude;
	
	private Double flightDestinationLatitude;
	
	private Double flightDestinationLongitude;

	public ItineraryEntity() {
	}

	public ItineraryEntity(String itineraryId, String source,
			String destination, Date travelStartDate, Date travelEndDate,
			String flightName, String flightSource, String flightDestination,
			Date flightDeparture, Date flightArrival, String class_, int hops,
			String operatedBy , Double flightSourceLatitude , Double flightSourceLongitude ,Double flightDestinationLatitude , Double flightDestinationLongitude) {
		super();
		this.class_ = class_;
		this.destination = destination;
		this.travelEndDate = travelEndDate;
		this.itineraryId = itineraryId;
		this.source = source;
		this.travelStartDate = travelStartDate;
		this.flightDestination = flightDestination;
		this.flightName = flightName;
		this.flightSource = flightSource;
		this.hops = hops;
		this.operatedBy = operatedBy;
		this.flightDeparture = flightDeparture;
		this.flightArrival = flightArrival;
		this.flightSourceLatitude =  flightSourceLatitude;
		this.flightSourceLongitude = flightSourceLongitude;
		this.flightDestinationLatitude =  flightDestinationLatitude;
		this.flightDestinationLongitude = flightDestinationLongitude;
	}

	public int getIdFlightItinerary() {
		return this.idFlightItinerary;
	}

	public void setIdFlightItinerary(int idFlightItinerary) {
		this.idFlightItinerary = idFlightItinerary;
	}

	public String getClass_() {
		return this.class_;
	}

	public void setClass_(String class_) {
		this.class_ = class_;
	}

	public String getDestination() {
		return this.destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getItineraryId() {
		return this.itineraryId;
	}

	public void setItineraryId(String itineraryId) {
		this.itineraryId = itineraryId;
	}

	public String getSource() {
		return this.source;
	}

	public void setSource(String source) {
		this.source = source;
	}	

	public Date getTravelEndDate() {
		return travelEndDate;
	}

	public void setTravelEndDate(Date travelEndDate) {
		this.travelEndDate = travelEndDate;
	}

	public Date getTravelStartDate() {
		return travelStartDate;
	}

	public void setTravelStartDate(Date travelStartDate) {
		this.travelStartDate = travelStartDate;
	}

	public String getFlightDestination() {
		return flightDestination;
	}

	public void setFlightDestination(String flightDestination) {
		this.flightDestination = flightDestination;
	}

	public String getFlightName() {
		return flightName;
	}

	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}

	public String getFlightSource() {
		return flightSource;
	}

	public void setFlightSource(String flightSource) {
		this.flightSource = flightSource;
	}

	public int getHops() {
		return hops;
	}

	public void setHops(int hops) {
		this.hops = hops;
	}

	public String getOperatedBy() {
		return operatedBy;
	}

	public void setOperatedBy(String operatedBy) {
		this.operatedBy = operatedBy;
	}

	public Date getFlightDeparture() {
		return flightDeparture;
	}

	public void setFlightDeparture(Date flightDeparture) {
		this.flightDeparture = flightDeparture;
	}

	public Date getFlightArrival() {
		return flightArrival;
	}

	public void setFlightArrival(Date flightArrival) {
		this.flightArrival = flightArrival;
	}

	public Double getFlightSourceLatitude() {
		return flightSourceLatitude;
	}

	public void setFlightSourceLatitude(Double flightSourceLatitude) {
		this.flightSourceLatitude = flightSourceLatitude;
	}

	public Double getFlightSourceLongitude() {
		return flightSourceLongitude;
	}

	public void setFlightSourceLongitude(Double flightSourceLongitude) {
		this.flightSourceLongitude = flightSourceLongitude;
	}

	public Double getFlightDestinationLatitude() {
		return flightDestinationLatitude;
	}

	public void setFlightDestinationLatitude(Double flightDestinationLatitude) {
		this.flightDestinationLatitude = flightDestinationLatitude;
	}

	public Double getFlightDestinationLongitude() {
		return flightDestinationLongitude;
	}

	public void setFlightDestinationLongitude(Double flightDestinationLongitude) {
		this.flightDestinationLongitude = flightDestinationLongitude;
	}

	
	

}