package com.ge.predix.airline.postgresql.entity;

import java.io.Serializable;

import javax.persistence.*;


/**
 * The persistent class for the mappingbaginfo database table.
 * 
 */
@Entity
@Table(name = "mappingbaginfo")
@NamedQuery(name="MappingBagEntity.findAll", query="SELECT m FROM MappingBagEntity m")
public class MappingBagEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idmappingBag;
	
	private String baggageId;

	private String itineraryId;

	public MappingBagEntity() {
	}
	
	public MappingBagEntity(String baggageId, String itineraryId) {
		super();
		this.baggageId = baggageId;
		this.itineraryId = itineraryId;
	}

	public int getIdmappingBag() {
		return idmappingBag;
	}

	public void setIdmappingBag(int idmappingBag) {
		this.idmappingBag = idmappingBag;
	}

	public String getBaggageId() {
		return baggageId;
	}

	public void setBaggageId(String baggageId) {
		this.baggageId = baggageId;
	}

	public String getItineraryId() {
		return itineraryId;
	}

	public void setItineraryId(String itineraryId) {
		this.itineraryId = itineraryId;
	}

	

}