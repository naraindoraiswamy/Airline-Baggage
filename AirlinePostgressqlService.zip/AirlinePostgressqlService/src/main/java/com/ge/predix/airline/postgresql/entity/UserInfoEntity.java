package com.ge.predix.airline.postgresql.entity;
/*package com.ge.predix.solsvc.training.alarmservice.entity;

import java.io.Serializable;

import javax.persistence.*;

import java.util.List;


*//**
 * The persistent class for the userinfo database table.
 * 
 *//*
@Entity
@Table(name = "userinfo")
@NamedQuery(name="UserInfoEntity.findAll", query="SELECT u FROM UserInfoEntity u")
public class UserInfoEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idUser;

	private String address;

	private String firstName;

	private String information;

	private String lastName;

	private String password;

	private String userName;

	//bi-directional many-to-one association to Mappingbaginfo
	@OneToMany(mappedBy="userinfo")
	private List<MappingBagEntity> mappingbaginfos;

	public UserInfoEntity() {
	}

	public int getIdUser() {
		return this.idUser;
	}

	public void setIdUser(int idUser) {
		this.idUser = idUser;
	}

	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getInformation() {
		return this.information;
	}

	public void setInformation(String information) {
		this.information = information;
	}

	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUserName() {
		return this.userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public List<MappingBagEntity> getMappingbaginfos() {
		return this.mappingbaginfos;
	}

	public void setMappingbaginfos(List<MappingBagEntity> mappingbaginfos) {
		this.mappingbaginfos = mappingbaginfos;
	}

	public MappingBagEntity addMappingbaginfo(MappingBagEntity mappingbaginfo) {
		getMappingbaginfos().add(mappingbaginfo);
		mappingbaginfo.setUserinfo(this);

		return mappingbaginfo;
	}

	public MappingBagEntity removeMappingbaginfo(MappingBagEntity mappingbaginfo) {
		getMappingbaginfos().remove(mappingbaginfo);
		mappingbaginfo.setUserinfo(null);

		return mappingbaginfo;
	}

}*/