package com.ge.predix.airline.postgresql.jpa.init;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;

import org.apache.commons.lang.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.ge.predix.airline.postgresql.entity.BaggageInfoEntity;
import com.ge.predix.airline.postgresql.entity.ItineraryEntity;
import com.ge.predix.airline.postgresql.repository.IBaggageInfoEntityRepository;
import com.ge.predix.airline.postgresql.repository.IItineraryEntityRepository;

@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class InitAlarmServiceData {
	
	@Autowired
	private IBaggageInfoEntityRepository baggageInfoRepo;

	
	@Autowired
	private IItineraryEntityRepository itineraryRepo;
	
	
	
	@PostConstruct
	public void initAlarmServiceData(){
		
		Date currentDate =  new Date();
		Date reachingDate = DateUtils.addHours(currentDate, 21);
		/*List<FlightsInfoEntity> flightsInfoEntityList = new ArrayList<FlightsInfoEntity>();
		FlightsInfoEntity flightsInfoEntity = new FlightsInfoEntity("IND3456", "BANGLORE", "NEW DELHI", currentDate, DateUtils.addHours(currentDate, 3), 1, "Jet Airways");
		flightsInfoEntityList.add(flightsInfoEntity);
		flightsInfoEntity = new FlightsInfoEntity("EMR4568", "NEW DELHI", "NEW YORK",currentDate,  DateUtils.addHours(currentDate, 18), 2, "Emirates");
		flightsInfoEntityList.add(flightsInfoEntity);
		flightInfoRepo.save(flightsInfoEntityList);*/
		
		List<ItineraryEntity> itineraryEntityList = new ArrayList<ItineraryEntity>();
		ItineraryEntity itineraryEntity = new ItineraryEntity("ITT3451", "BANGLORE", "NEWYORK", currentDate, reachingDate, "IND3456", "BANGLORE", "NEW DELHI", currentDate, DateUtils.addHours(currentDate, 3), "Business" , 1, "Jet Airways" , 13.198291, 77.709678,28.556172, 77.100033);
		itineraryEntityList.add(itineraryEntity);
		itineraryEntity = new ItineraryEntity("ITT3451", "BANGLORE", "NEWYORK", currentDate, reachingDate, "EMR4568", "NEW DELHI", "NEW YORK",currentDate,  DateUtils.addHours(currentDate, 18), "Business" , 2, "Emirates Airways" , 28.556172, 77.100033, 40.641303, -73.778150);
		itineraryEntityList.add(itineraryEntity);
		
		itineraryEntity = new ItineraryEntity("ITT3452", "MUMBAI", "LONDON", currentDate, reachingDate, "IND1451", "MUMABAI", "DUBAI", currentDate, DateUtils.addHours(currentDate, 2), "Business" , 1, "Jet Airways" ,19.089590, 72.865185, 25.253291, 55.365619);
		itineraryEntityList.add(itineraryEntity);
		itineraryEntity = new ItineraryEntity("ITT3452", "MUMBAI", "LONDON", currentDate, reachingDate, "EMR2562", "DUBAI", "LONDON",currentDate,  DateUtils.addHours(currentDate, 17), "Business" , 2, "Emirates Airways" ,25.253291, 55.365619 , 51.504576, 0.049771);
		itineraryEntityList.add(itineraryEntity);
		
		itineraryEntity = new ItineraryEntity("ITT3453", "BANGLORE", "LOS VEGAS", currentDate, reachingDate, "IND3453", "BANGLORE", "DUBAI", currentDate, DateUtils.addHours(currentDate, 5), "Business" , 1, "Jet Airways" ,13.198291, 77.709678 ,25.253291, 55.365619);
		itineraryEntityList.add(itineraryEntity);
		itineraryEntity = new ItineraryEntity("ITT3453", "BANGLORE", "LOS VEGAS", currentDate, reachingDate, "EMR4564", "DUBAI", "NEW YORK",currentDate,  DateUtils.addHours(currentDate, 18), "Business" , 2, "Emirates Airways" ,25.253291, 55.365619 ,40.641303, -73.778150);
		itineraryEntityList.add(itineraryEntity);		
		itineraryRepo.save(itineraryEntityList);
		
		//Adding Baggageinfo 
		List<BaggageInfoEntity> baggageInfoList = new ArrayList<BaggageInfoEntity>();
		BaggageInfoEntity baggageInfoEntity = new BaggageInfoEntity("Duffel Bag", "6869604894875671", "LF1300", 140, 30 , "Check-in");
		baggageInfoList.add(baggageInfoEntity);		
		baggageInfoEntity = new BaggageInfoEntity("Rolling Backpack", "6869604894875674", "LF1303", 130, 20 , "Check-in");
		baggageInfoList.add(baggageInfoEntity);
		baggageInfoEntity = new BaggageInfoEntity("Rolling Suitcase", "6869604894875675", "LF1304", 125, 30 ,"Check-in");
		baggageInfoList.add(baggageInfoEntity);		
		baggageInfoRepo.save(baggageInfoList);
		
		
	}
	
	
	
	
	
}
