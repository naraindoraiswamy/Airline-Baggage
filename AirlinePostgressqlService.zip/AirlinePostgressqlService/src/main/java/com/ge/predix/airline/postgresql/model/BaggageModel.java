package com.ge.predix.airline.postgresql.model;

public class BaggageModel {
	
	private String description;

	private String imei;

	private String uniqueBagId;
	
	private int dimensions;
	
	private int weight;
	
	private String status;

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getImei() {
		return imei;
	}

	public void setImei(String imei) {
		this.imei = imei;
	}

	public String getUniqueBagId() {
		return uniqueBagId;
	}

	public void setUniqueBagId(String uniqueBagId) {
		this.uniqueBagId = uniqueBagId;
	}

	public int getDimensions() {
		return dimensions;
	}

	public void setDimensions(int dimensions) {
		this.dimensions = dimensions;
	}

	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	

}
