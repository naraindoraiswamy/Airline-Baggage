package com.ge.predix.airline.postgresql.model;

import java.util.Date;
import java.util.List;

public class ItineraryModel {
	
	private String class_;

	private String destination;
	
	private Date travelEndDate;

	private String itineraryId;

	private String source;
	
	private Date travelStartDate;

	// Flight Details

	private String flightDestination;

	private String flightName;

	private String flightSource;

	private int hops;

	private String operatedBy;
	
	private Date flightDeparture;	
	
	private Date flightArrival;	

	private Double flightSourceLatitude;
	
	private Double flightSourceLongitude;
	
	private Double flightDestinationLatitude;
	
	private Double flightDestinationLongitude;
	
	
	public String getClass_() {
		return class_;
	}

	public void setClass_(String class_) {
		this.class_ = class_;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public Date getTravelEndDate() {
		return travelEndDate;
	}

	public void setTravelEndDate(Date travelEndDate) {
		this.travelEndDate = travelEndDate;
	}

	public String getItineraryId() {
		return itineraryId;
	}

	public void setItineraryId(String itineraryId) {
		this.itineraryId = itineraryId;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public Date getTravelStartDate() {
		return travelStartDate;
	}

	public void setTravelStartDate(Date travelStartDate) {
		this.travelStartDate = travelStartDate;
	}

	public String getFlightDestination() {
		return flightDestination;
	}

	public void setFlightDestination(String flightDestination) {
		this.flightDestination = flightDestination;
	}

	public String getFlightName() {
		return flightName;
	}

	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}

	public String getFlightSource() {
		return flightSource;
	}

	public void setFlightSource(String flightSource) {
		this.flightSource = flightSource;
	}

	public int getHops() {
		return hops;
	}

	public void setHops(int hops) {
		this.hops = hops;
	}

	public String getOperatedBy() {
		return operatedBy;
	}

	public void setOperatedBy(String operatedBy) {
		this.operatedBy = operatedBy;
	}

	public Date getFlightDeparture() {
		return flightDeparture;
	}

	public void setFlightDeparture(Date flightDeparture) {
		this.flightDeparture = flightDeparture;
	}

	public Date getFlightArrival() {
		return flightArrival;
	}

	public void setFlightArrival(Date flightArrival) {
		this.flightArrival = flightArrival;
	}

	public Double getFlightSourceLatitude() {
		return flightSourceLatitude;
	}

	public void setFlightSourceLatitude(Double flightSourceLatitude) {
		this.flightSourceLatitude = flightSourceLatitude;
	}

	public Double getFlightSourceLongitude() {
		return flightSourceLongitude;
	}

	public void setFlightSourceLongitude(Double flightSourceLongitude) {
		this.flightSourceLongitude = flightSourceLongitude;
	}

	public Double getFlightDestinationLatitude() {
		return flightDestinationLatitude;
	}

	public void setFlightDestinationLatitude(Double flightDestinationLatitude) {
		this.flightDestinationLatitude = flightDestinationLatitude;
	}

	public Double getFlightDestinationLongitude() {
		return flightDestinationLongitude;
	}

	public void setFlightDestinationLongitude(Double flightDestinationLongitude) {
		this.flightDestinationLongitude = flightDestinationLongitude;
	}

	
	
	


}
