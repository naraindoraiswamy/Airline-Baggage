package com.ge.predix.airline.postgresql.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Generated("Sateesh")
@JsonPropertyOrder({ "itineraryId", "uniqueBagId" })
public class MappingItineraryAndBagModel {

	@JsonProperty("itineraryId")
	private String itineraryId;
	@JsonProperty("uniqueBagId")
	private List<String> uniqueBagId = new ArrayList<String>();
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	/**
	 *
	 * @return The itineraryId
	 */
	@JsonProperty("itineraryId")
	public String getItineraryId() {
		return itineraryId;
	}

	/**
	 *
	 * @param itineraryId
	 *            The itineraryId
	 */
	@JsonProperty("itineraryId")
	public void setItineraryId(String itineraryId) {
		this.itineraryId = itineraryId;
	}

	/**
	 *
	 * @return The uniqueBagId
	 */
	@JsonProperty("uniqueBagId")
	public List<String> getUniqueBagId() {
		return uniqueBagId;
	}

	/**
	 *
	 * @param uniqueBagId
	 *            The uniqueBagId
	 */
	@JsonProperty("uniqueBagId")
	public void setUniqueBagId(List<String> uniqueBagId) {
		this.uniqueBagId = uniqueBagId;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

}
