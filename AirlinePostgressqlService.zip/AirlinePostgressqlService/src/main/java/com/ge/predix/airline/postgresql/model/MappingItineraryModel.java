package com.ge.predix.airline.postgresql.model;

import java.util.LinkedList;
import java.util.List;

public class MappingItineraryModel {
	
	private LinkedList<ItineraryModel> itineraryModelList;
	
	private List<String> selectedBaggageIdList;

	private List<String> nonSelectedBaggageIdList;

	public LinkedList<ItineraryModel> getItineraryModelList() {
		return itineraryModelList;
	}

	public void setItineraryModelList(LinkedList<ItineraryModel> itineraryModelList) {
		this.itineraryModelList = itineraryModelList;
	}

	public List<String> getSelectedBaggageIdList() {
		return selectedBaggageIdList;
	}

	public void setSelectedBaggageIdList(List<String> selectedBaggageIdList) {
		this.selectedBaggageIdList = selectedBaggageIdList;
	}

	public List<String> getNonSelectedBaggageIdList() {
		return nonSelectedBaggageIdList;
	}

	public void setNonSelectedBaggageIdList(List<String> nonSelectedBaggageIdList) {
		this.nonSelectedBaggageIdList = nonSelectedBaggageIdList;
	}
	
	

	}
