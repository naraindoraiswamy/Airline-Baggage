package com.ge.predix.airline.postgresql.repository;

import java.util.LinkedList;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.ge.predix.airline.postgresql.entity.ItineraryEntity;

@Repository
public interface IItineraryEntityRepository extends
PagingAndSortingRepository<ItineraryEntity, String> {

	@SuppressWarnings("javadoc")
	String GET_ITINERARY_LIST_BY_ID = "select a from ItineraryEntity a where a.itineraryId=?1 order by a.hops ASC";
	String GET_ITINERARY_LIST = "select DISTINCT a.itineraryId from ItineraryEntity a group by a.idFlightItinerary,a.itineraryId";

	@Override
	List<ItineraryEntity> findAll();

	@Query(GET_ITINERARY_LIST_BY_ID)
	LinkedList<ItineraryEntity> getItineraryListById(String itineraryId);

	@Query(GET_ITINERARY_LIST)
	LinkedList<String> getItineraryList();
}
