package com.ge.predix.airline.postgresql.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.ge.predix.airline.postgresql.entity.MappingBagEntity;

@Repository
public interface IMappingBagEntityRepository extends PagingAndSortingRepository<MappingBagEntity, String>{

	String GET_MAPPING_BAGGAGE_LIST_BY_ITINERARY_ID = "select a.baggageId from MappingBagEntity a where a.itineraryId=?1";
	String GET_MAPPING_OBJ_BY_ITINERARY_ID = "select a from MappingBagEntity a where a.itineraryId=?1";
	
	@Override
	List<MappingBagEntity> findAll();
	
	@Query(GET_MAPPING_BAGGAGE_LIST_BY_ITINERARY_ID)
	List<String> getMappingBaggageListByItineraryId(String itineraryId);
	
	@Query(GET_MAPPING_OBJ_BY_ITINERARY_ID)
	List<MappingBagEntity> getMappingObjByItineraryId(String itineraryId);
	
	
}
