package com.ge.predix.airline.postgresql.repository;
/*package com.ge.predix.solsvc.training.alarmservice.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.ge.predix.solsvc.training.alarmservice.entity.UserInfoEntity;

public interface IUserInfoEntityRepository extends CrudRepository<UserInfoEntity, String>{

	
	
	@Override
	List<UserInfoEntity> findAll();
}
*/