package com.ge.predix.airline.postgresql.util;

import org.springframework.stereotype.Service;

import com.ge.predix.airline.postgresql.entity.BaggageInfoEntity;
import com.ge.predix.airline.postgresql.entity.ItineraryEntity;
import com.ge.predix.airline.postgresql.model.BaggageModel;
import com.ge.predix.airline.postgresql.model.ItineraryModel;

@Service
public class ConvertEntityToModel {
	
	 public BaggageModel getBaggageModel(BaggageInfoEntity baggageInfoEntity)
	    {
		 BaggageModel baggageModel = new BaggageModel();
		 baggageModel.setUniqueBagId(baggageInfoEntity.getUniqueBagId());
		 baggageModel.setImei(baggageInfoEntity.getImei());
		 baggageModel.setDimensions(baggageInfoEntity.getDimensions());
		 baggageModel.setWeight(baggageInfoEntity.getWeight());
		 baggageModel.setDescription(baggageInfoEntity.getDescription());
		 baggageModel.setStatus(baggageInfoEntity.getStatus());
	   
	    return baggageModel;
	    }
	 public ItineraryModel getItineraryModel(ItineraryEntity itineraryEntity)
	    {
		 ItineraryModel itineraryModel = new ItineraryModel();
		 itineraryModel.setItineraryId(itineraryEntity.getItineraryId());
		 itineraryModel.setSource(itineraryEntity.getSource());
		 itineraryModel.setDestination(itineraryEntity.getDestination());
		 itineraryModel.setTravelStartDate(itineraryEntity.getTravelStartDate());
		 itineraryModel.setTravelEndDate(itineraryEntity.getTravelEndDate());
		 itineraryModel.setFlightName(itineraryEntity.getFlightName());
		 itineraryModel.setFlightSource(itineraryEntity.getFlightSource());
		 itineraryModel.setFlightDestination(itineraryEntity.getFlightDestination());
		 itineraryModel.setFlightDeparture(itineraryEntity.getFlightDeparture());
		 itineraryModel.setFlightArrival(itineraryEntity.getFlightArrival());
		 itineraryModel.setClass_(itineraryEntity.getClass_());
		 itineraryModel.setHops(itineraryEntity.getHops());
		 itineraryModel.setOperatedBy(itineraryEntity.getOperatedBy());
		 itineraryModel.setFlightSourceLatitude(itineraryEntity.getFlightSourceLatitude());
		 itineraryModel.setFlightSourceLongitude(itineraryEntity.getFlightSourceLongitude());
		 itineraryModel.setFlightDestinationLatitude(itineraryEntity.getFlightDestinationLatitude());
		 itineraryModel.setFlightDestinationLongitude(itineraryEntity.getFlightDestinationLongitude());
		 
		 
	    return itineraryModel;
	    }
	 
	 
	 
}
