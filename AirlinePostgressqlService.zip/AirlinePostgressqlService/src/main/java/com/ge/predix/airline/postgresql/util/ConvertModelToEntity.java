package com.ge.predix.airline.postgresql.util;

import org.springframework.stereotype.Service;

import com.ge.predix.airline.postgresql.entity.BaggageInfoEntity;
import com.ge.predix.airline.postgresql.model.BaggageModel;
import com.ge.predix.airline.postgresql.model.MappingItineraryAndBagModel;
@Service
public class ConvertModelToEntity {
	
	public BaggageInfoEntity setBaggageInfoEntity(BaggageModel baggageModel)
    {
		System.out.println("Start setBaggageInfoEntity");
		System.out.println("BagId : " + baggageModel.getUniqueBagId());
		BaggageInfoEntity baggageInfoEntity = new BaggageInfoEntity();
		baggageInfoEntity.setUniqueBagId(baggageModel.getUniqueBagId());
		baggageInfoEntity.setImei(baggageModel.getImei());
		baggageInfoEntity.setDimensions(baggageModel.getDimensions());
		baggageInfoEntity.setWeight(baggageModel.getWeight());
		baggageInfoEntity.setDescription(baggageModel.getDescription());
		baggageInfoEntity.setStatus(baggageModel.getStatus());
		System.out.println("End setBaggageInfoEntity");
    return baggageInfoEntity;
    }
	
	

}
