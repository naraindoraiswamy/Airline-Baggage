package com.ge.predix.solsvc.dataingestion.handler;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.URL;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.net.ssl.HttpsURLConnection;

import org.apache.http.Header;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.security.oauth2.client.token.grant.client.ClientCredentialsResourceDetails;
import org.springframework.stereotype.Component;
import com.ge.predix.solsvc.bootstrap.tbs.entity.InjectionBody;
import com.ge.predix.solsvc.bootstrap.tbs.entity.InjectionMetric;
import com.ge.predix.solsvc.bootstrap.tbs.entity.InjectionMetricBuilder;
import com.ge.predix.solsvc.bootstrap.tsb.client.TimeseriesWSConfig;
import com.ge.predix.solsvc.bootstrap.tsb.factories.TimeseriesFactory;
import com.ge.predix.solsvc.dataingestion.api.Constants;
import com.ge.predix.solsvc.dataingestion.websocket.WebSocketClient;
import com.ge.predix.solsvc.dataingestion.websocket.WebSocketConfig;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/**
 * 
 * @author predix -
 */
@Component
public class TimeSeriesDataIngestionHandler extends BaseFactoryIT {

	private static Logger log = Logger
			.getLogger(TimeSeriesDataIngestionHandler.class);
	@Autowired
	private TimeseriesFactory timeSeriesFactory;

	@Autowired
	private AssetDataHandler assetDataHandler;

	@Autowired
	private TimeseriesWSConfig tsInjectionWSConfig;

	@Autowired
	private WebSocketConfig wsConfig;

	@Autowired
	private WebSocketClient wsClient;

	@SuppressWarnings("nls")
	@PostConstruct
	public void intilizeDataIngestionHandler() {
		log.info("*******************TimeSeriesDataIngestionHandler Initialization complete*********************");
	}
/*===========================Added by Infosys for IIC Baggage tracking==================================================*/
	private static long messageId = 0;

	private synchronized long getMessageId() {
		return messageId++;
	}
	
	public boolean uploadBaggageDataToTimeSeries(String dataReceived) {

		try {
			String str=dataReceived;
			JsonObject baggageObject = new JsonParser().parse(str)
					.getAsJsonObject();
			
			System.out.println("Bag object is: ");
			System.out.println(baggageObject);
			String tagName = baggageObject.get("BaggageId").getAsString();
			long timestamp = baggageObject.get("timestamp").getAsLong();
			double lattitude = baggageObject.get("lattitude").getAsDouble();
			double longitude = baggageObject.get("longitude").getAsDouble();
		
			List<Header> headers = null;
			headers = this.restClient.getOauthHttpHeaders(
					this.restConfig.getOauthClientId(),
					this.restConfig.getOauthClientIdEncode());
			this.restClient.addZoneToHeaders(headers,
					this.assetRestConfig.getZoneId());

			// Creating the injection metric and builder
			InjectionMetricBuilder builder = InjectionMetricBuilder.getInstance();
			InjectionMetric metric = new InjectionMetric(getMessageId());

			// InjectionBody body = new InjectionBody(bag.getBaggageId());
			InjectionBody body = new InjectionBody(tagName);
			// Adding the data points to the request body

			body.addDataPoint(timestamp,lattitude+","+longitude);

			// Building the structure of timeseries here
			metric.getBody().add(body);
			builder.addMetrics(metric);

			// Pushing it into the timeseries
			this.timeSeriesFactory.create(builder);
			System.out.println("<==============Calling Method postToWebSocketServer inside uploadBaggageDataToTimeSeries ====================>");
			wsClient.postToWebSocketServer(builder.build());
			log.info("Posted Data to Timeseries for tag: " + tagName);
			System.out.println("Posted the data to the timeseries");
			return true;
		}catch(Exception ex) {
			System.out.println("Error while processing the data");
			ex.printStackTrace();
			return false;
		}
		
	}


	/**
	 * @param nodeName
	 *            -
	 * @param value
	 *            -
	 * @return -
	 */
	@SuppressWarnings("nls")
	public Double getConvertedValue(String nodeName, Double value) {
		Double convValue = null;
		switch (nodeName.toLowerCase()) {
		case Constants.COMPRESSION_RATIO:
			convValue = value * 9.0 / 65535.0 + 1;
			break;
		case Constants.DISCHG_PRESSURE:
			convValue = value * 100.0 / 65535.0;
			break;
		case Constants.SUCT_PRESSURE:
			convValue = value * 100.0 / 65535.0;
			break;
		case Constants.MAX_PRESSURE:
			convValue = value * 100.0 / 65535.0;
			break;
		case Constants.MIN_PRESSURE:
			convValue = value * 100.0 / 65535.0;
			break;
		case Constants.VELOCITY:
			convValue = value * 0.5 / 65535.0;
			break;
		case Constants.TEMPERATURE:
			convValue = value * 200.0 / 65535.0;
			break;
		default:
			throw new UnsupportedOperationException("nameName=" + nodeName
					+ " not found");
		}
		return convValue;
	}

	/*
	 * private AssetMeter getAssetMeter(LinkedHashMap<String, AssetMeter>
	 * meters,String nodeName) { AssetMeter ret = null; if ( meters != null ) {
	 * for (Entry<String, AssetMeter> entry : meters.entrySet()) { AssetMeter
	 * assetMeter = entry.getValue(); //MeterDatasource dataSource =
	 * assetMeter.getMeterDatasource(); if ( assetMeter != null &&
	 * !assetMeter.getSourceTagId().isEmpty() && nodeName !=null &&
	 * nodeName.toLowerCase
	 * ().contains(assetMeter.getSourceTagId().toLowerCase())) { ret =
	 * assetMeter; return ret; } } }else {
	 * log.warn("2. asset has no assetmeters with matching nodeName"+ nodeName);
	 * } return ret; }
	 */
	@SuppressWarnings("nls")
	private OAuth2RestTemplate getRestTemplate(String clientId,
			String clientSecret) {
		// get token here based on username password;
		// ResourceOwnerPasswordResourceDetails resourceDetails = new
		// ResourceOwnerPasswordResourceDetails();
		ClientCredentialsResourceDetails clientDetails = new ClientCredentialsResourceDetails();
		clientDetails.setClientId(clientId);
		clientDetails.setClientSecret(clientSecret);
		String url = this.restConfig.getOauthResourceProtocol() + "://"
				+ this.restConfig.getOauthRestHost()
				+ this.restConfig.getOauthResource();
		clientDetails.setAccessTokenUri(url);
		clientDetails.setGrantType("client_credentials");

		OAuth2RestTemplate restTemplate = new OAuth2RestTemplate(clientDetails);

		return restTemplate;
	}

	
	
	/*===========================Added by Infosys for IIC Baggage tracking==================================================*/
	
	public String getBaggageDataFromTimeSeries(String baggageId,String startTime, String endTime, String order) {
		String payload = "{\"start\": 9y-ago,\"end\": 1mi-ago,\"tags\": [{\"name\": \""
				+baggageId
				+ "\",\"order\": \"" + order + "\"}]}";
		System.out.println("Time series query: " + payload);

		String authorization = this.getBearerToken();
		System.out.println("Token is: " + authorization);

		String queryURI = this.timeSeriesRestConfig.getQueryUri();
		System.out.println("Query URI is: ******** : " + queryURI);
		String zoneId = this.timeSeriesRestConfig.getZoneId();
		System.out.println("ZoneID Values is: \n" + zoneId);

		try {
			// Actually making the post call
			URL url = new URL(queryURI);
			HttpsURLConnection connection = (HttpsURLConnection) url
					.openConnection();

			// Configuring the headers
			connection.setRequestMethod("POST");
			connection.setRequestProperty("Authorization", authorization);
			connection.setRequestProperty("Predix-Zone-Id", zoneId);

			// Connecting and printing the data
			connection.setDoOutput(true);

			connection.setDoInput(true);

			DataOutputStream dos = new DataOutputStream(
					connection.getOutputStream());

			dos.writeBytes(payload);
			dos.flush();
			dos.close();

			DataInputStream dis = new DataInputStream(
					connection.getInputStream());
			StringBuffer buffer = new StringBuffer();
			for (int c = dis.read(); c != -1; c = dis.read()) {
				buffer.append((char) c); // System.out.print((char) c);
			}
			dis.close();

			System.out
					.println("------------------Time series Get Result-----------------------");
			System.out.println("Query Resp Code:"
					+ connection.getResponseCode());
			System.out.println("Query Resp Message:"
					+ connection.getResponseMessage());
			System.out.println("Query Resp Body: " + buffer.toString());
			System.out
					.println("------------------Time series Get Result-----------------------");

			return buffer.toString();

		} catch (Exception ex) {
			System.out.println("Exception while making a post call");
			ex.printStackTrace();
			return "FAIL";
		}
	}

	private String getBearerToken() {
		String[] oauthClient = restConfig.getOauthClientId().split(":");
		String clientId = oauthClient[0];
		String clientSecret = oauthClient[1];

		System.out.println("******************************");
		System.out.println("Client id: " + clientId);
		System.out.println("Client secret: " + clientSecret);
		System.out.println("******************************");

		String authorization = "Bearer "
				+ getRestTemplate(clientId, clientSecret).getAccessToken()
						.getValue();
		// System.out.println("Token is: "+authorization);
		return authorization;
	}
	
}
