/*
 * Copyright (c) 2015 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */
 
package com.ge.predix.solsvc.dataingestion.websocket;
import org.springframework.context.EnvironmentAware;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

/**
 * 
 * @author predix -
 */
@Component
public class WebSocketConfig implements EnvironmentAware
{
    
   // @Value("${predixWebSocketURI}")
   // private String predixWebSocketURI;
    String predixWebSocketURI = "wss://airline-websocket-server.run.aws-usw02-pr.ice.predix.io/livestream/baggage";
    /**
	 * @return the predixWebSocketURI
	 */
	public String getPredixWebSocketURI() {
		return this.predixWebSocketURI.trim();
	}

	public WebSocketConfig(){
	}
	/**
	 * @param predixWebSocketURI the predixWebSocketURI to set
	 */
	public void setPredixWebSocketURI(String predixWebSocketURI) {
		this.predixWebSocketURI = predixWebSocketURI;
	}

	@SuppressWarnings("nls")
	@Override
	public void setEnvironment(Environment env) {
		this.predixWebSocketURI = env.getProperty("predixWebSocketURI");
		
	}
    
}