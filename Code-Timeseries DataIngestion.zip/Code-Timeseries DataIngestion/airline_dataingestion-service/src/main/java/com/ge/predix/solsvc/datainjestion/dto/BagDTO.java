package com.ge.predix.solsvc.datainjestion.dto;

public class BagDTO {
private String BaggageId;
private Double lattitude;
private Double longitude;
private Long  timestamp;
public String getBaggageId() {
	return BaggageId;
}
public void setBaggageId(String baggageId) {
	BaggageId = baggageId;
}
public Double getLattitude() {
	return lattitude;
}
public void setLattitude(Double lattitude) {
	this.lattitude = lattitude;
}
public Double getLongitude() {
	return longitude;
}
public void setLongitude(Double longitude) {
	this.longitude = longitude;
}
public Long getTimestamp() {
	return timestamp;
}
public void setTimestamp(Long timestamp) {
	this.timestamp = timestamp;
}

}
