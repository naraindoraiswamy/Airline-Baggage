package com.ge.predix.solsvc.websocket;

//@RunWith(SpringJUnit4ClassRunner.class)
//@SpringApplicationConfiguration(classes = PredixWebsocketServerApplication.class)
public class PredixWebsocketServerApplicationTests {

	//@Test
	public void contextLoads() {
	}

}
