package com.ge.predix.solsvc.util;

/*===========================Added by Infosys for IIC Baggage tracking==================================================*/

import java.io.BufferedReader;
import java.io.InputStreamReader;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
public class HttpUtil {
	
	
	public static boolean postData(String url, String payload) {
		try{
			sendPost(url, payload);
			return true;
		}catch(Exception ex) {
			ex.printStackTrace();
			System.out.println("Exception while posting the data");
		}
		return false;
	}
	public static void sendPost(String url, String data) throws Exception {
		
		HttpClient httpClient = HttpClientBuilder.create().build();
		HttpPost post = new HttpPost(url);

		// add header
		post.setHeader("User-Agent", "Mozilla/5.0");
		System.out.println("data==================="+ data);
		StringEntity requestEntity = new StringEntity(data);
		
		post.setEntity(requestEntity);
		post.setHeader("Content-type", "application/json");
		HttpResponse response = httpClient.execute(post);
		System.out.println("\nSending 'POST' request to URL : " + url);
		System.out.println("Post parameters : " + post.getEntity());
		System.out.println("Response Code : " + 
                                    response.getStatusLine().getStatusCode());

		BufferedReader rd = new BufferedReader(
                        new InputStreamReader(response.getEntity().getContent()));

		StringBuffer result = new StringBuffer();
		String line = "";
		while ((line = rd.readLine()) != null) {
			result.append(line);
		}

		System.out.println(result.toString());
	}
}