package com.ge.predix.solsvc.websocket;

import java.io.IOException;

import javax.websocket.CloseReason;
import javax.websocket.EndpointConfig;
import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.ge.predix.solsvc.util.HttpUtil;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/**
 * 
 * @author 212546387 -
 */
@Component
@ServerEndpoint(value="/livestream/{nodeId}")
public class ServerEndPoint{
	
	private String nodeId;
	
	private static Logger logger = LoggerFactory.getLogger(ServerEndPoint.class);
	
    /**
     * @param nodeId1 - nodeId for the session
     * @param session - session object
     * @param ec -
     */
    @OnOpen
    public void onOpen(@PathParam(value="nodeId") String nodeId1, final Session session, EndpointConfig ec) {
    	this.nodeId = nodeId1;
    	logger.info("Server: opened... for Node Id : "+nodeId1+" : " + session.getId()); //$NON-NLS-1$ //$NON-NLS-2$
    }
    
    /*===========================Added by Infosys for IIC Baggage tracking==================================================*/
    
   // private static final String postURL ="http://localhost:9191/baggageData";
    private static final String postURL = "https://airline-dataingestion.run.aws-usw02-pr.ice.predix.io/baggageData";
    /**
     * @param message - Message from the pay load
     * @param session - session object for current session
     * @throws IOException -
     */
    @OnMessage
    public void OnMessage(String message,Session session) throws IOException {
    	logger.info("Websocket Message : "+message);
    	logger.info("Node Id: "+this.nodeId);
    	try {
	    	if ("messages".equalsIgnoreCase(this.nodeId)) { //$NON-NLS-1$
	    		//Make http call and send the data to the web socket
	    		HttpUtil.postData(postURL, message);
	    		
	    		//Using GET
	    	/*	JsonObject msgObj = new JsonParser().parse(message).getAsJsonObject();
	    		String id = msgObj.get("baggageId").getAsString();
	    		Double lat = msgObj.get("lattitude").getAsDouble();
	    		Double longi = msgObj.get("longitude").getAsDouble();
	    		Long ts = msgObj.get("timestamp").getAsLong();
	    		
	    		String url = postURL+"1"+"?id="+id+"&lat="+lat+"&long="+longi+"&ts="+ts;
	    		
	    		URL obj = new URL(url);
	    		HttpURLConnection con = (HttpURLConnection) obj.openConnection();

	    		// optional default is GET
	    		con.setRequestMethod("GET");

	    		//add request header
	    		con.setRequestProperty("User-Agent", "Mozilla/5.0");

	    		int responseCode = con.getResponseCode();
	    		System.out.println("\nSending 'GET' request to URL : " + url);
	    		System.out.println("Response Code : " + responseCode);

	    		BufferedReader in = new BufferedReader(
	    		        new InputStreamReader(con.getInputStream()));
	    		String inputLine;
	    		StringBuffer response = new StringBuffer();

	    		while ((inputLine = in.readLine()) != null) {
	    			response.append(inputLine);
	    		}
	    		in.close();

	    		//print result
	    		System.out.println(response.toString()); */
	    		
	    		JsonParser parser = new JsonParser();
	    		JsonObject o = (JsonObject)parser.parse(message);
	    		//JsonArray nodes = o.getAsJsonArray("body"); //$NON-NLS-1$
	    		String currentNodeName = this.nodeId;
	    		for(Session s : session.getOpenSessions()){
	    			if (!"messages".equals(s.getPathParameters().get("nodeId"))) { //$NON-NLS-1$ //$NON-NLS-2$
	    				String pNodeName = s.getPathParameters().get("nodeId"); //$NON-NLS-1$
	    				//Sending the data to the ws urls which are connected to the same end point
	    				if(currentNodeName.equalsIgnoreCase(pNodeName)){
	    					//Make http call and send the data to the web socket
	    					s.getBasicRemote().sendText(message.toString());
	    				}
	    			}
	    		}
	    		String respons = "{\"messageId\": "+o.get("messageId")+",\"statusCode\": 202}"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
				session.getBasicRemote().sendText(respons);
	    	}else {
	    		session.getBasicRemote().sendText("SUCCESS"); //$NON-NLS-1$
	    	}
    	}catch(Exception ex){
    		logger.error("Exception in onMessage ",ex); //$NON-NLS-1$
    		throw new RuntimeException(ex);
    	}
    }

    private JsonObject findJsonObjectByName(JsonArray nodes,String pNodeName){
    	for (int i=0;i<nodes.size();i++) {
    		JsonObject node = (JsonObject)nodes.get(i);
    		String nodeName = node.get("name").getAsString(); //$NON-NLS-1$
    		if (pNodeName.equalsIgnoreCase(nodeName.trim())) {
    			return node;
    		}
    	}
    	return null;
    }
    /**
     * @param session - session object 
     * @param closeReason - The reason of close of session
     */
    @OnClose
    public void onClose(Session session, CloseReason closeReason) {
    	logger.info("Server: Session " + session.getId() + " closed because of " + closeReason.toString()); //$NON-NLS-1$ //$NON-NLS-2$
    }

    /**
     * @param session - current session object
     * @param t - Throwable instance containing error info
     */
    @OnError
    public void onError(Session session, Throwable t) {
    	logger.error("Server: Session " + session.getId() + " closed because of " + t.getMessage()); //$NON-NLS-1$ //$NON-NLS-2$
    }
}
