/**
 * Configure Angular unit test (mostly in karma.conf.js)
 */
module.exports = {
    runner: {
        configFile: 'karma.conf.js',
        singleRun: true
    }
};
