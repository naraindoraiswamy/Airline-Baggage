# predix-webwebsocket-server
Websocket server to listen and broadcast data

